#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tabuleiro.h"
#include "comandos.h"
#include "historico.h"

#define MAX_CMD 100

int main(void){
    Jogo *jogo = NULL;
    Historico *historico = criar_historico();
    char comando[MAX_CMD];

    printf("Bem-vindo ao Puzzle!\n");
    printf("Comandos disponíveis:\n");
    printf("  l <arquivo> - Carregar tabuleiro\n");
    printf("  g <arquivo> - Gravar tabuleiro\n");
    printf("  b <coord>   - Pintar casa de branco (ex: b a1)\n");
    printf("  r <coord>   - Riscar casa (ex: r a1)\n");
    printf("  v           - Verificar restrições\n");
    printf("  d           - Desfazer última jogada\n");
    printf("  s           - Sair\n");

    int aux = 0;
    while(aux==0){
        printf("> ");
        
        if(fgets(comando, sizeof(comando), stdin)){
            comando[strcspn(comando, "\n")] = '\0';
            
            if(processar_comando(&jogo, &historico, comando) == 1){//comando sair retorna 1
                aux=1;
            }
        }
    }

    if(jogo){
        destruir_jogo(jogo);
    }
    destruir_historico(historico);
    
    printf("Foi bom jogar com você! Até a próxima!\n");
    return 0;
}
