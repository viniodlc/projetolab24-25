#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include "comandos.h"
#include "tabuleiro.h"
#include "historico.h"
#include "jogo.h"
#include "io.h"
#include "verificacoes.h"

#define MAX_CMD 100

static void construir_caminho(const char *nome_arquivo, char *caminho_completo, size_t tamanho){
    if(nome_arquivo[0] == '/' || (nome_arquivo[0] == '.' && nome_arquivo[1] == '/')){
        strncpy(caminho_completo, nome_arquivo, tamanho);
        return;
    }
    snprintf(caminho_completo, tamanho, "puzzles/%s", nome_arquivo);
}

int executar_comando_carregar(Jogo **jogo, Historico **historico, const char *args){
    if(!args || strlen(args) == 0){
        printf("Uso: l <nome_arquivo>\n");
        return -1;
    }

    char caminho_completo[MAX_CMD];
    construir_caminho(args, caminho_completo, sizeof(caminho_completo));
    
    if(access(caminho_completo, R_OK) != 0){
        printf("Erro: Arquivo '%s' não encontrado ou sem permissão\n", caminho_completo);
        return -1;
    }

    if(*jogo){
        destruir_jogo(*jogo);
        *jogo = NULL;
    }

    *jogo = ler_jogo_ficheiro(caminho_completo);
    if(!*jogo){
        printf("Erro: Arquivo '%s' com formato inválido\n", caminho_completo);
        return -1;
    }

    //limpa o histórico ao carregar novo jogo
    if (*historico){
        destruir_historico(*historico);
        *historico = criar_historico();
    }

    printf("Tabuleiro carregado com sucesso!\n");
    imprimir_tabuleiro(*jogo);
    return 0;
}

int executar_comando_gravar(const Jogo *jogo, const char *args){
    if(!jogo){
        printf("Erro: Nenhum tabuleiro carregado\n");
        return -1;
    }

    if(!args || strlen(args) == 0){
        printf("Uso: g <nome_arquivo>\n");
        return -1;
    }

    if(gravar_jogo_ficheiro(jogo, args) != 0){
        printf("Erro ao salvar em '%s'\n", args);
        return -1;
    }

    printf("Tabuleiro salvo em '%s' - Sucesso!\n", args);
    return 0;
}

int executar_comando_pintar(Jogo *jogo, Historico **historico, const char *args){
    if(!jogo){
        printf("Erro: Nenhum tabuleiro carregado\n");
        return -1;
    }

    if (!args || strlen(args) == 0){
        printf("Uso: b <coordenada> (ex: b a1)\n");
        return -1;
    }

    //salva estado atual no histórico antes de modificar
    empilhar_estado(historico, jogo);

    int linha, coluna;
    if(coordenada_para_indice(args, &linha, &coluna) != 0){
        printf("Erro: Coordenada '%s' inválida\n", args);
        return -1;
    }

    if(pintar_branco(jogo, linha, coluna) != 0){
        printf("Não pode fazer isso nessa casa!\n");
        return -1;
    }

    imprimir_tabuleiro(jogo);
    return 0;
}

int executar_comando_riscar(Jogo *jogo, Historico **historico, const char *args){
    if(!jogo){
        printf("Erro: Nenhum tabuleiro carregado\n");
        return -1;
    }

    if(!args || strlen(args) == 0){
        printf("Uso: r <coordenada> (ex: r a1)\n");
        return -1;
    }

    //salva estado atual no histórico antes de modificar
    empilhar_estado(historico, jogo);

    int linha, coluna;
    if(coordenada_para_indice(args, &linha, &coluna) != 0){
        printf("Erro: Coordenada '%s' inválida\n", args);
        return -1;
    }

    if(riscar_casa(jogo, linha, coluna)!=0){
        printf("Não pode fazer isso nessa casa!\n");
        return -1;
    }

    imprimir_tabuleiro(jogo);
    return 0;
}

int executar_comando_verificar(const Jogo *jogo){
    if (!jogo){
        printf("Erro: Nenhum tabuleiro carregado\n");
        return -1;
    }

    printf("Verificando restrições...\n");
    RelatorioViolacoes relatorio;
    verificar_restricoes(jogo, &relatorio);
    imprimir_violacoes(&relatorio);
    
    return relatorio.count == 0 ? 0 : -1;
}

int executar_comando_desfazer(Jogo **jogo, Historico **historico){
    if(!*jogo){
        printf("Erro: Nenhum tabuleiro carregado\n");
        return -1;
    }

    if(historico_vazio(*historico)){
        printf("Nada para desfazer\n");
        return -1;
    }

    Jogo *anterior = desempilhar_estado(historico);
    if(!anterior){
        printf("Erro ao recuperar estado anterior\n");
        return -1;
    }

    //jogo atual pelo estado anterior
    destruir_jogo(*jogo);
    *jogo = anterior;

    printf("Estado anterior restaurado:\n");
    imprimir_tabuleiro(*jogo);
    return 0;
}

int executar_comando_sair(){
    return 1;
}

int processar_comando(Jogo **jogo, Historico **historico, const char *input){
    if(!input || strlen(input) == 0){
        return -1;
    }

    char cmd = input[0];
    const char *args = input + (input[1] == ' ' ? 2 : 1); //pula o comando e o espaço caso exista 

    switch (cmd){
        case 'l': return executar_comando_carregar(jogo, historico, args);
        case 'g': return executar_comando_gravar(*jogo, args);
        case 'b': return executar_comando_pintar(*jogo, historico, args);
        case 'r': return executar_comando_riscar(*jogo, historico, args);
        case 'v': return executar_comando_verificar(*jogo);
        case 'd': return executar_comando_desfazer(jogo, historico);
        case 's': return executar_comando_sair();
        default:
            printf("Comando não reconhecido. Comandos disponíveis:\n");
            printf("  l <arquivo> - Carregar tabuleiro\n");
            printf("  g <arquivo> - Gravar tabuleiro\n");
            printf("  b <coord>   - Pintar casa de branco\n");
            printf("  r <coord>   - Riscar casa\n");
            printf("  v           - Verificar restrições\n");
            printf("  d           - Desfazer última jogada\n");
            printf("  s           - Sair\n");
            return -1;
    }
}
