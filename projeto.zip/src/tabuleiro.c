#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tabuleiro.h"

Jogo *criar_jogo(int linhas, int colunas) {
    Jogo *j = malloc(sizeof(Jogo));
    j->linhas = linhas;
    j->colunas = colunas;
    j->matriz = malloc(sizeof(char *) * linhas);
    for (int i = 0; i < linhas; i++) {
        j->matriz[i] = malloc(sizeof(char) * colunas);
    }
    return j;
}

Jogo *copiar_jogo(const Jogo *original) {
    if (!original) return NULL;
    
    Jogo *copia = criar_jogo(original->linhas, original->colunas);
    for (int i = 0; i < original->linhas; i++) {
        memcpy(copia->matriz[i], original->matriz[i], original->colunas * sizeof(char));
    }
    return copia;
}

void destruir_jogo(Jogo *jogo) {
    if (!jogo) return;
    
    for (int i = 0; i < jogo->linhas; i++) {
        free(jogo->matriz[i]);
    }
    free(jogo->matriz);
    free(jogo);
}

void imprimir_tabuleiro(const Jogo *jogo) {
    for (int i = 0; i < jogo->linhas; i++) {
        for (int j = 0; j < jogo->colunas; j++) {
            printf("%c ", jogo->matriz[i][j]);
        }
        printf("\n");
    }
}

int coordenada_para_indice(const char *coord, int *linha, int *coluna) {
    if (coord[0] < 'a' || coord[0] > 'z') return -1;
    *coluna = coord[0] - 'a';
    *linha = atoi(coord + 1) - 1;
    return 0;
}
