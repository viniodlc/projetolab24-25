#include "jogo.h"
#include <ctype.h>

int pintar_branco(Jogo *jogo, int linha, int coluna){
    if(!jogo || linha < 0 || linha >= jogo->linhas || coluna < 0 || coluna >= jogo->colunas){
        return -1;
    }
    char atual = jogo->matriz[linha][coluna];
    if (atual == '#' || isupper(atual)) return -1;
    jogo->matriz[linha][coluna] = toupper(atual);
    return 0;
}

int riscar_casa(Jogo *jogo, int linha, int coluna) {
    if(!jogo || linha < 0 || linha >= jogo->linhas || coluna < 0 || coluna >= jogo->colunas){
        return -1;
    }
    
    char atual = jogo->matriz[linha][coluna];
    if(atual == '#' || isupper(atual)) return -1;
    jogo->matriz[linha][coluna] = '#';
    return 0;
}
