#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "verificacoes.h"

/*
estruturas verificacoes.h
typedef struct {
    char mensagem[100];
    char coordenadas[50];
} Violacao;

typedef struct {
    Violacao violacoes[100];
    int count;
} RelatorioViolacoes;
*/
//static para evitar conflitos, nao altera funcionamento original
static void adicionar_violacao(RelatorioViolacoes *relatorio, const char *msg, const char *coord){
    if(relatorio->count < 100){
        snprintf(relatorio->violacoes[relatorio->count].mensagem, sizeof(relatorio->violacoes[relatorio->count].mensagem), "%s", msg);
        snprintf(relatorio->violacoes[relatorio->count].coordenadas, sizeof(relatorio->violacoes[relatorio->count].coordenadas), "%s", coord);
        relatorio->count++;
    }
}

static void dfs(const Jogo *jogo, int linha, int coluna, int visitados[jogo->linhas][jogo->colunas]){
    if(linha < 0 || linha >= jogo->linhas || coluna < 0 || coluna >= jogo->colunas) 
        return;
    if(visitados[linha][coluna] || !isupper(jogo->matriz[linha][coluna])) 
        return;
    //só faz a busca recursiva caso não tenha feito antes ou esteja dentro dos limites do tabuleiro
    
    visitados[linha][coluna] = 1;
    
    dfs(jogo, linha-1, coluna, visitados);
    dfs(jogo, linha+1, coluna, visitados);
    dfs(jogo, linha, coluna-1, visitados);
    dfs(jogo, linha, coluna+1, visitados);
}

void verificar_conectividade(const Jogo *jogo, RelatorioViolacoes *relatorio){
    int visitados[jogo->linhas][jogo->colunas];
    memset(visitados, 0, sizeof(visitados));
    
    int componente = 0;
    
    for(int i = 0; i < jogo->linhas; i++){
        for(int j = 0; j < jogo->colunas; j++){
            if(isupper(jogo->matriz[i][j]) && !visitados[i][j]){ //!indica que visitados[i][j] nao foi acessado
                if(componente > 0){
                    char coord[32]; //quanto maior, menor chance de overflow
                    snprintf(coord, sizeof(coord), "%c%d", 'a'+j, i+1);
                    adicionar_violacao(relatorio, "Casa branca desconectada", coord);
                }
                dfs(jogo, i, j, visitados);
                componente++;
            }
        }
    }
}

void verificar_vizinhos_riscados(const Jogo *jogo, RelatorioViolacoes *relatorio){
    for(int i = 0; i < jogo->linhas; i++){
        for(int j = 0; j < jogo->colunas; j++){
            if (jogo->matriz[i][j] == '#'){
                char coord[32]; //aumentado por segurança
                snprintf(coord, sizeof(coord), "%c%d", 'a'+j, i+1);
                
                if(i > 0 && !isupper(jogo->matriz[i-1][j])){
                    adicionar_violacao(relatorio, "Vizinho superior não branco", coord);
                }
                if(i < jogo->linhas-1 && !isupper(jogo->matriz[i+1][j])){
                    adicionar_violacao(relatorio, "Vizinho inferior não branco", coord);
                }
                if(j > 0 && !isupper(jogo->matriz[i][j-1])) {
                    adicionar_violacao(relatorio, "Vizinho esquerdo não branco", coord);
                }
                if(j < jogo->colunas-1 && !isupper(jogo->matriz[i][j+1])){
                    adicionar_violacao(relatorio, "Vizinho direito não branco", coord);
                }
            }
        }
    }
}

void verificar_letras_duplicadas(const Jogo *jogo, RelatorioViolacoes *relatorio) {
    //verificacao por linha
    for(int i = 0; i < jogo->linhas; i++){
        for(int j = 0; j < jogo->colunas; j++){
            if(isupper(jogo->matriz[i][j])){
                for(int k = j+1; k < jogo->colunas; k++){
                    if(jogo->matriz[i][j] == jogo->matriz[i][k]){
                        char coords[64]; //aumentado
                        snprintf(coords, sizeof(coords), "%c%d e %c%d", 
                                 'a'+j, i+1, 'a'+k, i+1);
                        adicionar_violacao(relatorio, "Letras brancas duplicadas na linha", coords);
                    }
                }
            }
        }
    }
    
    //coluna
    for(int j = 0; j < jogo->colunas; j++){
        for(int i = 0; i < jogo->linhas; i++){
            if (isupper(jogo->matriz[i][j])){
                for(int k = i+1; k < jogo->linhas; k++){
                    if (jogo->matriz[i][j] == jogo->matriz[k][j]){
                        char coords[64];
                        snprintf(coords, sizeof(coords), "%c%d e %c%d", 
                                 'a'+j, i+1, 'a'+j, k+1);
                        adicionar_violacao(relatorio, "Letras brancas duplicadas na coluna", coords);
                    }
                }
            }
        }
    }
}

void verificar_restricoes(const Jogo *jogo, RelatorioViolacoes *relatorio){
    relatorio->count = 0;
    verificar_letras_duplicadas(jogo, relatorio);
    verificar_vizinhos_riscados(jogo, relatorio);
    verificar_conectividade(jogo, relatorio);
}

void imprimir_violacoes(const RelatorioViolacoes *relatorio){
    if (relatorio->count == 0){
        printf("Todas as restrições estão a ser respeitadas!\n");
        return;
    }

    printf("Foram encontradas %d violações:\n", relatorio->count);
    for(int i = 0; i < relatorio->count; i++){
        printf("- %s: %s\n", relatorio->violacoes[i].mensagem, 
                            relatorio->violacoes[i].coordenadas);
    }
}

