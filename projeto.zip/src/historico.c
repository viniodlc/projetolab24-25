#include <stdlib.h>
#include <string.h>
#include "historico.h"
#include "tabuleiro.h"

Historico* criar_historico(){
    Historico *h = malloc(sizeof(Historico));
    if(h == NULL) return NULL;

    h->estado = NULL;//ainda não há um estado empilhado
    h->proximo = NULL;//nenhum próximo histórico
    memset(&h->relatorio, 0, sizeof(RelatorioViolacoes)); //Zera o relatório

    return h;
}

void destruir_historico(Historico *historico){
    while(historico != NULL){
        Historico *aux = historico;
        historico = historico->proximo;
        destruir_jogo(aux->estado);
        free(aux);
    }
}

void empilhar_estado(Historico **historico, const Jogo *jogo){
    if(*historico == NULL) return;

    //caso o nó cabeça ainda não tenha estado, usa ele
    if((*historico)->estado == NULL){
        (*historico)->estado = criar_jogo(jogo->linhas, jogo->colunas);
        for(int i=0;i<jogo->linhas;i++){
            memcpy((*historico)->estado->matriz[i], jogo->matriz[i], jogo->colunas * sizeof(char));
        }
        verificar_restricoes(jogo, &(*historico)->relatorio);
        return;
    }

    //caso contrário cria um novo nó e empilha
    Historico *novo = malloc(sizeof(Historico));
    novo->estado = criar_jogo(jogo->linhas, jogo->colunas);

    for (int i = 0; i < jogo->linhas; i++) {
        memcpy(novo->estado->matriz[i], jogo->matriz[i], jogo->colunas * sizeof(char));
    }

    verificar_restricoes(jogo, &novo->relatorio);

    novo->proximo = *historico;
    *historico = novo;
}

Jogo* desempilhar_estado(Historico **historico) {
    if (*historico == NULL) return NULL;
    
    Historico *temp = *historico;
    Jogo *estado = temp->estado;
    *historico = temp->proximo;
    free(temp);
    
    return estado;
}

int historico_vazio(const Historico *historico) {
    //se a pilha está vazia (sem estados empilhados)
    return historico == NULL || historico->estado == NULL;
}
