#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "io.h"

Jogo *ler_jogo_ficheiro(const char *caminho){
    if (!caminho || strlen(caminho) == 0){
        fprintf(stderr, "Erro: Caminho do arquivo inválido\n");
        return NULL;
    }

    FILE *f = fopen(caminho, "r");
    if(!f){
        perror("Erro ao abrir arquivo");
        return NULL;
    }
    int linhas, colunas;
    if(fscanf(f, "%d %d", &linhas, &colunas) != 2){
        fprintf(stderr, "Erro: Formato inválido - linhas/colunas\n");
        fclose(f);
        return NULL;
    }
    //consome o restante da linha
    while(fgetc(f) != '\n');

    Jogo *j = criar_jogo(linhas, colunas);
    if(!j){
        fprintf(stderr, "Erro: Falha ao alocar memória para o jogo\n");
        fclose(f);
        return NULL;
    }

    for(int i=0;i<linhas;i++){
        for(int j_idx=0; j_idx<colunas;j_idx++){
            int c = fgetc(f);
            if(c == EOF){
                fprintf(stderr, "Erro: Arquivo incompleto na linha %d\n", i+1);
                destruir_jogo(j);
                fclose(f);
                return NULL;
            }
            if(c == '\n'){
                j_idx--;
                continue;
            }
            j->matriz[i][j_idx] = (char)c;
        }
        
        //verificação se terminou a linha corretamente
        int c;
        do{
            c = fgetc(f);
        }while (c != '\n' && c != EOF);
    }

    fclose(f);
    return j;
}

int gravar_jogo_ficheiro(const Jogo *jogo, const char *caminho){
    FILE *f = fopen(caminho, "w");
    if(!f)return -1;

    fprintf(f, "%d %d\n", jogo->linhas, jogo->colunas);
    for(int i=0; i<jogo->linhas;i++){
        for(int j = 0; j < jogo->colunas; j++){
            fputc(jogo->matriz[i][j], f);
        }
        fputc('\n', f);
    }

    fclose(f);
    return 0;
}
