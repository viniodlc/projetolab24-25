#ifndef JOGO_H
#define JOGO_H

#include "tabuleiro.h"

int pintar_branco(Jogo *jogo, int linha, int coluna);
int riscar_casa(Jogo *jogo, int linha, int coluna);

#endif
