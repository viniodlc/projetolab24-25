#ifndef TABULEIRO_H
#define TABULEIRO_H

typedef struct {
    int linhas;
    int colunas;
    char **matriz;
} Jogo;

Jogo *criar_jogo(int linhas, int colunas);
Jogo *copiar_jogo(const Jogo *original);
void destruir_jogo(Jogo *jogo);
void imprimir_tabuleiro(const Jogo *jogo);
int coordenada_para_indice(const char *coord, int *linha, int *coluna);

#endif
