#ifndef HISTORICO_H
#define HISTORICO_H

#include "tabuleiro.h"
#include "verificacoes.h"

typedef struct Historico {
    Jogo *estado;
    RelatorioViolacoes relatorio;
    struct Historico *proximo;
} Historico;

Historico* criar_historico();
void destruir_historico(Historico *historico);
void empilhar_estado(Historico **historico, const Jogo *jogo);
Jogo* desempilhar_estado(Historico **historico);
int historico_vazio(const Historico *historico);

#endif
