#ifndef IO_H
#define IO_H

#include "tabuleiro.h"

// Lê um jogo a partir de um ficheiro (formato: L C + matriz de L linhas)
Jogo *ler_jogo_ficheiro(const char *caminho);
int gravar_jogo_ficheiro(const Jogo *jogo, const char *caminho);

#endif
