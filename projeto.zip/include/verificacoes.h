#ifndef VERIFICACOES_H
#define VERIFICACOES_H

#include "tabuleiro.h"

typedef struct {
    char mensagem[100];
    char coordenadas[50];
} Violacao;

typedef struct {
    Violacao violacoes[100];
    int count;
} RelatorioViolacoes;

void verificar_restricoes(const Jogo *jogo, RelatorioViolacoes *relatorio);
void verificar_letras_duplicadas(const Jogo *jogo, RelatorioViolacoes *relatorio);
void verificar_vizinhos_riscados(const Jogo *jogo, RelatorioViolacoes *relatorio);
void verificar_conectividade(const Jogo *jogo, RelatorioViolacoes *relatorio);
void imprimir_violacoes(const RelatorioViolacoes *relatorio);

#endif
