#ifndef COMANDOS_H
#define COMANDOS_H

#include "tabuleiro.h"
#include "historico.h"

int processar_comando(Jogo **jogo, Historico **historico, const char *input);
int executar_comando_carregar(Jogo **jogo, Historico **historico, const char *args);
int executar_comando_gravar(const Jogo *jogo, const char *args);
int executar_comando_pintar(Jogo *jogo, Historico **historico, const char *args);
int executar_comando_riscar(Jogo *jogo, Historico **historico, const char *args);
int executar_comando_verificar(const Jogo *jogo);
int executar_comando_desfazer(Jogo **jogo, Historico **historico);
int executar_comando_sair();

#endif
