#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/tabuleiro.h"
#include "../include/jogo.h"
#include "../include/io.h"
#include "../include/historico.h"
#include "../include/verificacoes.h"

//função auxiliar para criar tabuleiro de teste
Jogo* criar_tabuleiro_teste(){
    Jogo *jogo = criar_jogo(3, 3);
    if(jogo){
        for(int i = 0; i < 3; i++){
            for(int j = 0; j < 3; j++){
                jogo->matriz[i][j] = 'a' + i + j;
            }
        }
    }
    return jogo;
}

//testes básicos existentes iguais a primeira versão
void test_criar_destruir_jogo(){
    Jogo *j = criar_jogo(3, 3);
    CU_ASSERT_PTR_NOT_NULL(j);
    if(j){
        CU_ASSERT_EQUAL(j->linhas, 3);  
        CU_ASSERT_EQUAL(j->colunas, 3);
        destruir_jogo(j);
    }
}

void test_coordenadas(){
    int linha, coluna;
    
    CU_ASSERT_EQUAL(coordenada_para_indice("a1", &linha, &coluna), 0);
    CU_ASSERT_EQUAL(linha, 0);
    CU_ASSERT_EQUAL(coluna, 0);
    
    CU_ASSERT_EQUAL(coordenada_para_indice("z26", &linha, &coluna), 0);
    CU_ASSERT_EQUAL(linha, 25);
    CU_ASSERT_EQUAL(coluna, 25);
    
    CU_ASSERT_EQUAL(coordenada_para_indice("A1", &linha, &coluna), -1);
    CU_ASSERT_EQUAL(coordenada_para_indice("1a", &linha, &coluna), -1);
}

void test_pintar_e_riscar(){
    Jogo *j = criar_jogo(2, 2);
    CU_ASSERT_PTR_NOT_NULL_FATAL(j);
    
    for (int i = 0; i < j->linhas; i++){
        for (int k = 0; k < j->colunas; k++){
            j->matriz[i][k] = 'a' + i + k;
        }
    }

    CU_ASSERT_EQUAL(pintar_branco(j, 0, 0), 0);
    CU_ASSERT_EQUAL(j->matriz[0][0], 'A');
    
    CU_ASSERT_EQUAL(riscar_casa(j, 0, 1), 0);
    CU_ASSERT_EQUAL(j->matriz[0][1], '#');

    CU_ASSERT_EQUAL(pintar_branco(j, -1, 0), -1);
    CU_ASSERT_EQUAL(riscar_casa(j, 0, -1), -1);

    destruir_jogo(j);
}

void test_io() {
    const char* test_file = "teste_io.txt";
    
    Jogo *j = criar_jogo(2, 2);
    CU_ASSERT_PTR_NOT_NULL_FATAL(j);
    
    j->matriz[0][0] = 'a';
    j->matriz[0][1] = 'b';
    j->matriz[1][0] = 'c';
    j->matriz[1][1] = 'd';

    CU_ASSERT_EQUAL(gravar_jogo_ficheiro(j, test_file), 0);

    Jogo *j2 = ler_jogo_ficheiro(test_file);
    CU_ASSERT_PTR_NOT_NULL_FATAL(j2);
    
    CU_ASSERT_EQUAL(j2->linhas, 2);
    CU_ASSERT_EQUAL(j2->colunas, 2);
    CU_ASSERT_EQUAL(j2->matriz[0][0], 'a');
    CU_ASSERT_EQUAL(j2->matriz[0][1], 'b');
    CU_ASSERT_EQUAL(j2->matriz[1][0], 'c');
    CU_ASSERT_EQUAL(j2->matriz[1][1], 'd');

    destruir_jogo(j);
    destruir_jogo(j2);
    remove(test_file);
}

//novos testes para a segunda parte do projeto

void test_historico() {
    Historico *historico = criar_historico();
    CU_ASSERT_PTR_NOT_NULL(historico);
    CU_ASSERT(historico_vazio(historico));
    
    Jogo *jogo1 = criar_tabuleiro_teste();
    CU_ASSERT_PTR_NOT_NULL_FATAL(jogo1);
    
    //empilha o primeiro estado do tabuleiro
    empilhar_estado(&historico, jogo1);
    CU_ASSERT(!historico_vazio(historico));
    
    //modifica o jogo
    jogo1->matriz[0][0] = 'X';
    
    //empilha segundo estado após comando
    empilhar_estado(&historico, jogo1);
    CU_ASSERT(!historico_vazio(historico));
    
    //desempilha
    Jogo *restaurado = desempilhar_estado(&historico);
    CU_ASSERT_PTR_NOT_NULL(restaurado);
    CU_ASSERT_EQUAL(restaurado->matriz[0][0], 'X');
    destruir_jogo(restaurado);
    
    //desempilha outra vez
    restaurado = desempilhar_estado(&historico);
    CU_ASSERT_PTR_NOT_NULL(restaurado);
    CU_ASSERT_EQUAL(restaurado->matriz[0][0], 'a');
    destruir_jogo(restaurado);
    
    CU_ASSERT(historico_vazio(historico));
    
    destruir_historico(historico);
    destruir_jogo(jogo1);
}

void test_verificacoes(){
    Jogo *jogo = criar_jogo(3, 3);
    CU_ASSERT_PTR_NOT_NULL_FATAL(jogo);
    
    //configuração com violações
    jogo->matriz[0][0] = 'A'; jogo->matriz[0][1] = 'A'; // Duplicado na linha
    jogo->matriz[1][0] = 'B'; jogo->matriz[2][0] = 'B'; // Duplicado na coluna
    jogo->matriz[1][1] = '#'; // Riscado com vizinhos não brancos
    
    RelatorioViolacoes relatorio = {0};
    verificar_restricoes(jogo, &relatorio);
    
    //deve encontrar 4 violações (duplicado na linha, duplicado na coluna, vizinho superior não branco Vizinho esquerdo não branco.)
    CU_ASSERT_EQUAL(relatorio.count, 4);
    
    //veifica se as mensagens estão corretas
    int tem_duplicado_linha = 0, tem_duplicado_coluna = 0, tem_vizinho = 0;
    for (int i = 0; i < relatorio.count; i++) {
        if (strstr(relatorio.violacoes[i].mensagem, "duplicadas na linha")) tem_duplicado_linha = 1;
        if (strstr(relatorio.violacoes[i].mensagem, "duplicadas na coluna")) tem_duplicado_coluna = 1;
        if (strstr(relatorio.violacoes[i].mensagem, "Vizinho")) tem_vizinho = 1;
    }
    
    CU_ASSERT(tem_duplicado_linha);
    CU_ASSERT(tem_duplicado_coluna);
    CU_ASSERT(tem_vizinho);
    
    destruir_jogo(jogo);
}

void test_conectividade() {
    Jogo *jogo = criar_jogo(3, 3);
    CU_ASSERT_PTR_NOT_NULL_FATAL(jogo);
    
    //áreas brancas desconectadas
    jogo->matriz[0][0] = 'A';
    jogo->matriz[2][2] = 'B';
    
    RelatorioViolacoes relatorio;
    verificar_conectividade(jogo, &relatorio);
    
    CU_ASSERT_EQUAL(relatorio.count, 1);
    CU_ASSERT_STRING_EQUAL(relatorio.violacoes[0].mensagem, "Casa branca desconectada");
    
    destruir_jogo(jogo);
}

int main() {
    if (CU_initialize_registry() != CUE_SUCCESS) {
        return CU_get_error();
    }

    CU_pSuite suite = CU_add_suite("Suite_Jogo", NULL, NULL);
    if (suite == NULL) {
        CU_cleanup_registry();
        return CU_get_error();
    }

    //testes mantidos
    if ((CU_add_test(suite, "Test criar/destruir jogo", test_criar_destruir_jogo) == NULL) ||
        (CU_add_test(suite, "Test coordenadas", test_coordenadas) == NULL) ||
        (CU_add_test(suite, "Test pintar e riscar", test_pintar_e_riscar) == NULL) ||
        (CU_add_test(suite, "Test IO", test_io) == NULL) ||
        //novos testes
        (CU_add_test(suite, "Test histórico", test_historico) == NULL) ||
        (CU_add_test(suite, "Test verificacoes", test_verificacoes) == NULL) ||
        (CU_add_test(suite, "Test conectividade", test_conectividade) == NULL)) {
        CU_cleanup_registry();
        return CU_get_error();
    }

    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    CU_cleanup_registry();

    return CU_get_error();
}
